var app = angular.module('financialApp', []);

app.controller('IndicatorController', ['$scope', '$http', function($scope, $http) {
  $scope.indicators = [
    { name: 'Dólar', id: 'dolar' },
    { name: 'Euro', id: 'euro' },
    { name: 'IPC', id: 'ipc' },
    { name: 'UF', id: 'uf' },
    { name: 'UTM', id: 'utm' }
  ];

  $scope.showDetails = function(indicator) {
    var apiUrl = `https://api.cmfchile.cl/api-sbifv3/recursos_api/${indicator.id}/${getApiPath(indicator.id)}?apikey=bf6b491ec46caf655a1204c927f559580679f4c4&formato=json`;

    $http.get(apiUrl)
      .then(function(response) {
        var details = response.data;
        if (indicator.id === 'utm') {
          // Filtra el valor del UTM para el mes actual
          var currentDate = new Date();
          var year = currentDate.getFullYear();
          var month = currentDate.getMonth() + 1; // Los meses en JavaScript van de 0 a 11
          details = details.UTMs && details.UTMs.UTM.find(item => item.Fecha.startsWith(`${year}-${month}`));
        }
        openDetailsWindow(details, indicator.name); // Pasa el nombre del indicador como argumento
      })
      .catch(function(error) {
        console.error('Error fetching data:', error);
      });
  };

  $scope.showGraph = function(indicator) {
    console.log('showGraph called for', indicator);

    // Obtener el indicador seleccionado (ajusta esto según tu enfoque de enrutamiento o cómo obtienes el indicador)
    var indicatorId = indicator.id;

    // Función para llenar el gráfico con datos desde la API
    function fillChartWithData() {
      getChartDataFromAPI(indicatorId) // Llama a la función que obtiene los datos de la API
        .then(function(data) {
          if (data) {
            // Supongamos que los datos tienen una propiedad "fechas" y una propiedad "valores"
            var fechas = data.fechas;
            var valores = data.valores;

            // Configuración del gráfico
            var options = {
              responsive: true,
              maintainAspectRatio: false // Permite ajustar el tamaño del gráfico
            };

            // Obtener el contexto del canvas
            var ctx = document.getElementById('myChart').getContext('2d');

            // Crear el gráfico
            var myChart = new Chart(ctx, {
              type: 'line', // Tipo de gráfico (puede ser 'line', 'bar', etc.)
              data: {
                labels: fechas, // Etiquetas para el eje X
                datasets: [
                  {
                    label: 'Valores',
                    data: valores, // Datos para el eje Y
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                  }
                ]
              },
              options: options
            });
          }
        });
    }

    // Llama a la función para llenar el gráfico al cargar el controlador
    fillChartWithData();
  };

  // Función para obtener los datos del indicador desde la API
  function getChartDataFromAPI(indicatorId) {
      var apiUrl = `https://api.cmfchile.cl/api-sbifv3/recursos_api/${indicatorId}/${getApiPath(indicatorId)}?apikey=bf6b491ec46caf655a1204c927f559580679f4c4&formato=json`;

    return $http.get(apiUrl)
      .then(function(response) {
        return response.data; // Supongamos que la respuesta contiene los datos necesarios
      })
      .catch(function(error) {
        console.error('Error fetching data:', error);
        return null;
      });
  }

  function getApiPath(indicatorId) {
    var currentDate = new Date();
    var year = currentDate.getFullYear();
    var month = currentDate.getMonth() + 1; // Los meses en JavaScript van de 0 a 11

    switch (indicatorId) {
      case 'dolar':
        return `periodo/${year}/${month - 1}/dias_i/1/${year}/${month}/dias_f/${currentDate.getDate()}`;
      case 'euro':
        return `periodo/${year}/${month - 1}/${currentDate.getDate()}/${year}/${month}/${currentDate.getDate()}`;
      case 'uf':
        return `anteriores/${year}/${month}`;
      case 'ipc':
        return `${year - 1}`;
      case 'utm':
        // Utiliza el recurso de fechas anteriores para el mes actual
        return `anteriores/${year}/${month}`;
      default:
        return '';
    }
  }

  function openDetailsWindow(details, indicatorName) {
    var modalDiv = document.createElement('div');
    modalDiv.className = 'modal fade';
    modalDiv.id = 'detailsModal';
    modalDiv.tabIndex = '-1';
    modalDiv.role = 'dialog';

    // Crear una tabla HTML para mostrar los detalles
    var tableHTML = `
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">${indicatorName}</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
    `;

    if (indicatorName === 'UTM') {
      // Mostrar solo el valor de UTM
      tableHTML += `<p>Valor: ${details.Valor}</p>`;
    } else {
      // Mostrar los detalles en una tabla
      tableHTML += `
        <table class="table">
          <thead>
            <tr>
              <th>Fecha</th>
              <th>Valor</th>
            </tr>
          </thead>
          <tbody>
      `;

      // Agregar filas a la tabla con los detalles
      for (var key in details) {
        if (details.hasOwnProperty(key) && Array.isArray(details[key])) {
          details[key].forEach(function (item) {
            tableHTML += `
              <tr>
                <td>${item.Fecha}</td>
                <td>${item.Valor}</td>
              </tr>
            `;
          });
        }
      }

      tableHTML += `
            </tbody>
          </table>
        `;
    }

    // Cerrar la tabla y el modal
    tableHTML += `
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
          </div>
        </div>
      </div>
    `;

    modalDiv.innerHTML = tableHTML;

    document.body.appendChild(modalDiv);

    $('#detailsModal').modal('show');

    $('#detailsModal').on('hidden.bs.modal', function () {
      $(this).remove();
    });
  }
}]);
