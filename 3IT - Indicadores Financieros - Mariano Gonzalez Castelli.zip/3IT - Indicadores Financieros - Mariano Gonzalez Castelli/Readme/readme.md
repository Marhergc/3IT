# Indicadores Financieros

Esta aplicación AngularJS muestra una lista de indicadores financieros y permite ver un listado de valores y gráficos correspondientes a cada indicador.

## Requisitos Previos
- [Node.js](https://nodejs.org/) y [npm](https://www.npmjs.com/) instalados en tu sistema.

## Configuración

1. Clona o descarga este repositorio en tu máquina local.

2. Abre una terminal y navega hasta la carpeta raíz de la aplicación.

3. Ejecuta el siguiente comando para instalar las dependencias de Node.js: npm install


4. Asegúrate de que tengas una conexión a Internet activa, ya que la aplicación obtiene datos financieros de una API en línea.

## Ejecución

1. Una vez que se hayan instalado las dependencias, ejecuta la aplicación con el siguiente comando: npm start

2. Abre tu navegador web y ve a la siguiente dirección: http://localhost:8000


3. La aplicación se cargará en tu navegador y podrás ver la lista de indicadores financieros.

## Uso

- Haz clic en el botón "Listado de valores" para ver una tabla con los valores del indicador seleccionado.

- Haz clic en el botón "Mostrar Gráfico" para ver un gráfico correspondiente al indicador seleccionado.

## Personalización

- Puedes personalizar la lista de indicadores y su comportamiento editando el archivo `app.js`. Asegúrate de reemplazar la URL de la API en la función `getChartDataFromAPI` con la URL correcta para obtener datos del indicador.

- Puedes personalizar los estilos de la aplicación editando el archivo `css/styles.css`.



Esta aplicación utiliza AngularJS para la lógica de front-end y Chart.js para la visualización de gráficos.