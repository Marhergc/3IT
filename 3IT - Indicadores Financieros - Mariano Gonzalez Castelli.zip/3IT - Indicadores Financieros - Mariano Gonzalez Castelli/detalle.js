var detalle = angular.module('detalle', ['financialApp']); // Asegúrate de incluir 'financialApp' como dependencia

detalle.controller('ChartController', ['$scope', function($scope) {
  // Obtén el indicador seleccionado (ajusta esto según tu enfoque de enrutamiento o cómo obtienes el indicador)
var indicatorId = 'dolar';

  // Función para llenar el gráfico con datos desde la API
function fillChartWithData() {
    console.log('fillChartWithData called');
    getChartDataFromAPI(indicatorId) // Llama a la función que obtiene los datos de la API
    .then(function(data) {
        if (data) {
          // Supongamos que los datos tienen una propiedad "fechas" y una propiedad "valores"
        var fechas = data.fechas;
        var valores = data.valores;

          // Configuración del gráfico
        var options = {
            responsive: true,
            maintainAspectRatio: false // Permite ajustar el tamaño del gráfico
        };

          // Obtener el contexto del canvas
        var ctx = document.getElementById('myChart').getContext('2d');

          // Crear el gráfico
        var myChart = new Chart(ctx, {
            type: 'line', // Tipo de gráfico (puede ser 'line', 'bar', etc.)
            data: {
              labels: fechas, // Etiquetas para el eje X
            datasets: [
                {
                label: 'Valores',
                  data: valores, // Datos para el eje Y
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
                }
            ]
            },
            options: options
        });
        }
    });
}

  // Llama a la función para llenar el gráfico al cargar el controlador
fillChartWithData();
}]);

